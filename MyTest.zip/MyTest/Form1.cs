﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void buttonRun_Click(object sender, EventArgs e)
        {
            var Result = await GetHtml();
            richTextBoxResponse.Text = Result;
        }

        private async Task<string> GetHtml()
        {
            string html = "";
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(textBoxURL.Text);
                response.EnsureSuccessStatusCode();
                response.Content.Headers.ContentType.CharSet = "utf-8";
                html = await response.Content.ReadAsStringAsync();
            }
            return html;
        }
    }
}
